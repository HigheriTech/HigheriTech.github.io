# Information
You Are An Idiot is back in windows!
You now can run in Windows, in browser and flash version realeased!

# Downloading
## Windows:

Simply run the .EXE file in the Releases

## MacOS:

If you want to play in MacOS look this form: https://echoone.com/filejuicer/formats/exe or https://wiki.winehq.org/Download

## Linux:

https://wiki.winehq.org/Download select your Version and Download

## Optional: Android

If you want to test in Andorid, DO IT, JUST DO IT!
But this do not work on iPhone: https://wiki.winehq.org/Download and It doesn't work well

# Credits

Youtube: https://www.youtube.com/channel/UCBEEHg4eBVw5pkZQyPh2fcQ (some videos is in Portuguese and others in English).

# How To Build From The Source Code

##### Soon
